"""Explicit checkpoint workflows and durable local steps (MIT).

Workflow state is explicit JSON. Python frames and ordinary local variables are
not checkpointed. A local step may execute again if its effect succeeds before
its result is durably acknowledged; use an external idempotency key when needed.
"""
from __future__ import annotations

import asyncio
import calendar
import ipaddress
from contextvars import ContextVar
from dataclasses import dataclass
from enum import StrEnum
from types import MappingProxyType
import inspect
import hashlib
import json
import math
import re
import unicodedata
from typing import Any

SCHEMA = "ledgence.workflow.activation.v1"
MAX_STEPS = 128
MAX_COMMANDS = 64
MAX_RECORD_BYTES = 128 * 1024
MAX_RECORDS_BYTES = 256 * 1024
MAX_DECISION_BYTES = 256 * 1024
MAX_FORK_BYTES = 128 * 1024
MAX_STATE_BYTES = 64 * 1024
MAX_CONTEXT_BYTES = 640 * 1024
MAX_WAIT_MS = 31_536_000_000
MAX_EVENT_BYTES = 64 * 1024
MAX_TIMESTAMP = 253402300799999
MAX_APPROVAL_BYTES = 32 * 1024
_APPROVAL_LOCAL_PREFIX = "_approval:"


class WorkflowError(Exception):
    """A workflow binding, decision, or runtime acknowledgement is invalid."""


class EffectOutcomeUnknown(Exception):
    """The provider cannot verify a final outcome for the approved action."""


class OperationKind(StrEnum):
    """Semantic kind of an application-owned durable operation."""
    MODEL = "model"
    TOOL = "tool"


class ApprovalProtection(StrEnum):
    """Execution contract declared when the workflow requests approval."""
    EXTERNAL_EFFECT = "external_effect"


class ApprovalStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


def _callable_name(fn, *, label="approval"):
    module = getattr(fn, "__module__", None)
    name = getattr(fn, "__qualname__", None)
    if not callable(fn) or not module or not name:
        raise WorkflowError(f"{label} callable requires a stable module and qualified name")
    return _text(module + ":" + name, f"{label} callable", 512)


def _same_callable(first, second):
    # Repeated access to the same Python bound method creates a new wrapper.
    return first is second or (inspect.ismethod(first) and inspect.ismethod(second)
                               and first.__func__ is second.__func__ and first.__self__ is second.__self__)


def _effective_arguments(fn, arguments, *, label="approval"):
    try:
        signature = inspect.signature(fn)
        bound = signature.bind(**arguments)
        bound.apply_defaults()
    except (TypeError, ValueError) as exc:
        raise WorkflowError(f"{label} arguments do not bind to the callable") from exc
    effective = {}
    for name, value in bound.arguments.items():
        kind = signature.parameters[name].kind
        if kind == inspect.Parameter.POSITIONAL_ONLY:
            raise WorkflowError(f"{label} callables must accept keyword arguments")
        if kind == inspect.Parameter.VAR_POSITIONAL:
            if value:
                raise WorkflowError(f"{label} callables must accept keyword arguments")
        elif kind == inspect.Parameter.VAR_KEYWORD:
            effective.update(value)
        else:
            effective[name] = value
    return effective


def _validate_action(action, *, authoritative=False):
    _fields(action, {"name", "version", "arguments"})
    _text(action["name"], "action name", 512)
    _text(action["version"], "action version")
    if type(action["arguments"]) is not dict:
        raise WorkflowError("approval arguments must be a JSON object")
    _encode(action["arguments"], MAX_APPROVAL_BYTES, authoritative=authoritative)
    _encode(action, MAX_APPROVAL_BYTES, 96, authoritative=authoritative)


def _validate_proposed_arguments(value, *, authoritative=False):
    if value is not None and type(value) is not dict:
        raise WorkflowError("proposed arguments must be a JSON object or None")
    _encode(value, MAX_APPROVAL_BYTES, authoritative=authoritative)


@dataclass(frozen=True, slots=True, init=False)
class ApprovalAction:
    """Frozen effective action; returned arguments are independent JSON copies."""
    _encoded: bytes

    def __init__(self, name, *, version, arguments):
        value = {"name": name, "version": version, "arguments": arguments}
        _validate_action(value)
        object.__setattr__(self, "_encoded", _encode(value, MAX_APPROVAL_BYTES, 96))

    @classmethod
    def for_callable(cls, fn, *, version, arguments):
        """Bind a callable's identity and freeze its validated keyword defaults.

        Perform domain-specific normalization before this call. Execution uses
        these saved arguments, including defaults, without re-running it.
        """
        _validate_action({"name": _callable_name(fn), "version": version, "arguments": arguments})
        return cls(_callable_name(fn), version=version, arguments=_effective_arguments(fn, arguments))

    @classmethod
    def _accepted(cls, value):
        result = object.__new__(cls)
        object.__setattr__(result, "_encoded", _encode(value, MAX_APPROVAL_BYTES, 96, authoritative=True))
        return result

    def to_dict(self):
        return json.loads(self._encoded)

    @property
    def name(self): return self.to_dict()["name"]

    @property
    def version(self): return self.to_dict()["version"]

    @property
    def arguments(self): return self.to_dict()["arguments"]


@dataclass(frozen=True, slots=True)
class ApprovalDecision:
    decision_id: str
    decision: str
    reviewer: str
    reason: str | None
    decided_at: int


def _validate_approval_protection(value):
    if "protection" in value and value["protection"] != ApprovalProtection.EXTERNAL_EFFECT:
        raise WorkflowError("invalid approval protection")


def _validate_approval(value):
    _fields(value, {"scope", "workflow_id", "key", "activation_id", "revision", "action",
                    "proposed_arguments", "created_at", "deadline", "status", "decision",
                    "resumed_activation_id"}, {"protection"})
    _validate_approval_protection(value)
    _fields(value["scope"], {"tenant_id", "namespace"})
    for name in ("tenant_id", "namespace"):
        _text(value["scope"][name], name)
    for name in ("workflow_id", "key", "activation_id"):
        _text(value[name], name)
    _integer(value["revision"], "revision")
    _validate_action(value["action"], authoritative=True)
    _validate_proposed_arguments(value["proposed_arguments"], authoritative=True)
    for name in ("created_at", "deadline"):
        _integer(value[name], name, maximum=MAX_TIMESTAMP)
    if not 0 <= value["deadline"] - value["created_at"] <= MAX_WAIT_MS:
        raise WorkflowError("invalid approval deadline")
    try:
        status = ApprovalStatus(value["status"])
    except (ValueError, TypeError) as exc:
        raise WorkflowError("invalid approval status") from exc
    decision = value["decision"]
    if status in (ApprovalStatus.APPROVED, ApprovalStatus.REJECTED):
        _fields(decision, {"decision_id", "decision", "reviewer", "reason", "decided_at"})
        for name in ("decision_id", "reviewer"):
            _text(decision[name], name)
        if decision["decision"] != ("approve" if status == ApprovalStatus.APPROVED else "reject"):
            raise WorkflowError("approval decision contradicts status")
        reason = decision["reason"]
        if reason is not None and (type(reason) is not str or len(reason.encode("utf-8")) > 4096):
            raise WorkflowError("approval reason must be at most 4096 UTF-8 bytes")
        _integer(decision["decided_at"], "decided_at", maximum=MAX_TIMESTAMP)
        if not value["created_at"] <= decision["decided_at"] < value["deadline"]:
            raise WorkflowError("approval decision falls outside its deadline")
    elif decision is not None:
        raise WorkflowError("unresolved approval cannot contain a decision")
    resumed = value["resumed_activation_id"]
    if resumed is not None:
        _text(resumed, "resumed_activation_id")
        if status in (ApprovalStatus.PENDING, ApprovalStatus.CANCELLED) or resumed == value["activation_id"]:
            raise WorkflowError("invalid resumed approval activation")


@dataclass(frozen=True, slots=True)
class Approval:
    """Immutable approval observation, not a bearer token or authorization input."""
    _encoded: bytes

    def to_dict(self): return json.loads(self._encoded)

    @property
    def status(self): return ApprovalStatus(self.to_dict()["status"])

    @property
    def protection(self):
        value = self.to_dict().get("protection")
        return None if value is None else ApprovalProtection(value)

    @property
    def action(self): return ApprovalAction._accepted(self.to_dict()["action"])

    @property
    def key(self): return self.to_dict()["key"]

    @property
    def scope(self): return self.to_dict()["scope"]

    @property
    def workflow_id(self): return self.to_dict()["workflow_id"]

    @property
    def activation_id(self): return self.to_dict()["activation_id"]

    @property
    def revision(self): return self.to_dict()["revision"]

    @property
    def resumed_activation_id(self): return self.to_dict()["resumed_activation_id"]

    @property
    def decision(self):
        value = self.to_dict()["decision"]
        return None if value is None else ApprovalDecision(**value)

    @property
    def proposed_arguments(self): return self.to_dict()["proposed_arguments"]

    @property
    def created_at(self): return self.to_dict()["created_at"]

    @property
    def deadline(self): return self.to_dict()["deadline"]


_workflow: ContextVar[WorkflowContext | None] = ContextVar("ledgence_workflow", default=None)
_local_owner: ContextVar[WorkflowContext | None] = ContextVar("ledgence_local_owner", default=None)


def _text(value, name, limit=128):
    try:
        raw = value.encode("utf-8") if type(value) is str else b""
    except UnicodeError as exc:
        raise WorkflowError(f"{name} must contain Unicode scalar values") from exc
    if (type(value) is not str or not value or len(raw) > limit
            or any(unicodedata.category(char) == "Cc" or 0xFDD0 <= ord(char) <= 0xFDEF
                   or ord(char) & 0xFFFE == 0xFFFE for char in value)):
        raise WorkflowError(f"{name} must be a nonempty string of at most {limit} UTF-8 bytes")
    return value


def _integer(value, name, minimum=0, maximum=(1 << 64) - 1):
    if type(value) is not int or not minimum <= value <= maximum:
        raise WorkflowError(f"invalid {name}")
    return value


def _replayed_action_json(text):
    def unique_fields(pairs):
        fields = dict(pairs)
        if len(fields) != len(pairs):
            raise WorkflowError("duplicate field in stored approved effect action")
        return fields

    try:
        # serde_json preserves a negative zero token as -0.0.
        action = json.loads(text, object_pairs_hook=unique_fields,
                            parse_int=lambda token: -0.0 if token == "-0" else int(token))
    except (ValueError, RecursionError) as exc:
        raise WorkflowError("invalid stored approved effect action") from exc
    return _encode(action, MAX_APPROVAL_BYTES, 96, authoritative=True).decode("utf-8")


def _fields(value, required, optional=()):
    if type(value) is not dict or not required <= value.keys() or value.keys() - required - set(optional):
        raise WorkflowError("invalid workflow object fields")


def _encode(value, limit, max_depth=64, *, authoritative=False):
    remaining = limit
    float_slack = 0

    def check(item, depth=0, ancestors=None):
        nonlocal remaining, float_slack
        remaining -= 1
        if remaining < 0:
            raise WorkflowError("workflow value exceeds its byte limit")
        if item is None or type(item) is bool:
            return
        if type(item) is str:
            if len(item) > remaining:
                raise WorkflowError("workflow string exceeds its byte limit")
            remaining -= len(item.encode("utf-8", errors="strict"))
            if remaining < 0:
                raise WorkflowError("workflow string exceeds its byte limit")
            return
        if type(item) is int:
            _integer(item, "JSON integer", -(1 << 63))
            return
        if type(item) is float:
            if not math.isfinite(item):
                raise WorkflowError("JSON number must be finite")
            if authoritative:
                # Rust's canonical finite float token uses at least three
                # bytes. CPython JSON emits float.__repr__ for this exact type.
                # Allow only that per-token possible expansion when copying
                # already accepted values; authored writes remain strict.
                width = len(repr(item))
                if width > 32:
                    raise WorkflowError("unsupported floating-point representation")
                float_slack += max(0, width - 3)
            return
        if type(item) not in (dict, list, tuple) or depth >= max_depth:
            raise WorkflowError("workflow values must be bounded JSON")
        ancestors = set() if ancestors is None else ancestors
        if id(item) in ancestors:
            raise WorkflowError("workflow values cannot contain cycles")
        ancestors.add(id(item))
        try:
            if type(item) is dict:
                for key, child in item.items():
                    if type(key) is not str:
                        raise WorkflowError("JSON keys must be strings")
                    check(key, depth + 1, ancestors)
                    check(child, depth + 1, ancestors)
            else:
                for child in item:
                    check(child, depth + 1, ancestors)
        finally:
            ancestors.remove(id(item))
    try:
        check(value)
        encoded_limit = limit + float_slack
        chunks = []
        length = 0
        encoder = json.JSONEncoder(ensure_ascii=False, allow_nan=False,
                                   separators=(",", ":"), sort_keys=True)
        for part in encoder.iterencode(value):
            chunk = part.encode("utf-8")
            length += len(chunk)
            if length > encoded_limit:
                raise WorkflowError("workflow value exceeds its byte limit")
            chunks.append(chunk)
        return b"".join(chunks)
    except (ValueError, TypeError, UnicodeError, OverflowError, RecursionError) as exc:
        raise WorkflowError("invalid workflow JSON value") from exc


def _freeze(value, limit, max_depth=64, *, authoritative=False):
    return json.loads(_encode(value, limit, max_depth, authoritative=authoritative))


def _validate_event_uri(value, *, absolute=False):
    """Validate RFC 3986 URI references without rewriting their identity."""
    atom = r"(?:[A-Za-z0-9._~!$&'()*+,;=\-]|%[0-9A-Fa-f]{2})"
    pchar = rf"(?:{atom}|[:@])"
    path_query, fragment_mark, fragment = value.partition("#")
    if absolute and fragment_mark:
        raise WorkflowError("dataschema must be an absolute URI without a fragment")
    path, query_mark, query = path_query.partition("?")
    if not re.fullmatch(rf"(?:{pchar}|[/?])*", fragment) or not re.fullmatch(rf"(?:{pchar}|[/?])*", query):
        raise WorkflowError("invalid CloudEvent URI query or fragment")
    scheme = re.match(r"[A-Za-z][A-Za-z0-9+.-]*:", path)
    if absolute and scheme is None:
        raise WorkflowError("dataschema must be an absolute URI")
    if scheme is not None:
        path = path[scheme.end():]
    authority = path.startswith("//")
    if authority:
        host, slash, rest = path[2:].partition("/")
        path = slash + rest
        if "@" in host:
            user, _, host = host.partition("@")
            if not re.fullmatch(rf"(?:{atom}|:)*", user):
                raise WorkflowError("invalid CloudEvent URI user information")
        if host.startswith("["):
            address, close, port = host[1:].partition("]")
            if not close or (port and not re.fullmatch(r":[0-9]*", port)):
                raise WorkflowError("invalid CloudEvent URI host")
            if re.fullmatch(r"v[0-9A-Fa-f]+\.[A-Za-z0-9._~!$&'()*+,;=:\-]+", address, re.IGNORECASE) is None:
                try:
                    if "%" in address:
                        raise ValueError("zone identifier is not an RFC3986 address")
                    ipaddress.IPv6Address(address)
                except ValueError as exc:
                    raise WorkflowError("invalid CloudEvent URI address") from exc
        else:
            name, colon, port = host.partition(":")
            if not re.fullmatch(rf"{atom}*", name) or (colon and not re.fullmatch(r"[0-9]*", port)):
                raise WorkflowError("invalid CloudEvent URI host or port")
    if not re.fullmatch(rf"(?:{pchar}|/)*", path):
        raise WorkflowError("invalid CloudEvent URI path")
    if scheme is None and not authority and ":" in path.partition("/")[0]:
        raise WorkflowError("relative CloudEvent URI first segment cannot contain a colon")


def _validate_event_trace(event):
    trace = event.get("traceparent")
    if trace is not None and (type(trace) is not str
            or not re.fullmatch(r"00-[0-9a-f]{32}-[0-9a-f]{16}-[0-9a-f]{2}", trace)
            or trace[3:35] == "0" * 32 or trace[36:52] == "0" * 16):
        raise WorkflowError("invalid CloudEvent traceparent")
    if "tracestate" not in event:
        return
    state = event["tracestate"]
    if trace is None or type(state) is not str or not state.isascii() or len(state) > 512:
        raise WorkflowError("invalid CloudEvent tracestate")
    members = state.split(",")
    if len(members) > 32:
        raise WorkflowError("too many CloudEvent tracestate members")
    seen = set()
    for member in members:
        member = member.strip(" ")
        if not member:
            continue
        key, equal, item = member.partition("=")
        if (not equal or not item or len(item) > 256 or key in seen
                or not re.fullmatch(r"(?:[a-z][a-z0-9_*/-]{0,255}|[a-z0-9][a-z0-9_*/-]{0,240}@[a-z][a-z0-9_*/-]{0,13})", key)
                or any(not 0x20 <= ord(char) <= 0x7e or char in ",=" for char in item)):
            raise WorkflowError("invalid CloudEvent tracestate member")
        seen.add(key)


def _valid_event_leap_second(year, month, day, hour, minute, offset_minutes):
    # Match time's final-UTC-second-of-a-month stand-in. Integer/calendar
    # arithmetic preserves year0000 and rollover into UTC year-1, unlike datetime.
    day_change, utc_minute = divmod(hour * 60 + minute - offset_minutes, 24 * 60)
    if utc_minute != 23 * 60 + 59:
        return False
    day += day_change
    if day < 1:
        month -= 1
        if month == 0:
            year, month = year - 1, 12
        day += calendar.monthrange(year, month)[1]
    elif day > calendar.monthrange(year, month)[1]:
        day -= calendar.monthrange(year, month)[1]
        month += 1
        if month == 13:
            year, month = year + 1, 1
    return -9999 <= year <= 9999 and day == calendar.monthrange(year, month)[1]


def _validate_event(value, *, authoritative=False):
    # Keep this portable common profile aligned with worker-api's borrowed
    # CloudEvent validator. Execution identity requirements do not apply here.
    _encode(value, MAX_EVENT_BYTES, 96, authoritative=authoritative)
    if type(value) is not dict:
        raise WorkflowError("CloudEvent must be an object")
    for name, item in value.items():
        if name == "data":
            continue
        if re.fullmatch(r"[a-z0-9]+", name) is None:
            raise WorkflowError("invalid CloudEvent context name")
        if type(item) is str:
            if any(unicodedata.category(c) == "Cc" or 0xFDD0 <= ord(c) <= 0xFDEF
                   or ord(c) & 0xFFFE == 0xFFFE for c in item):
                raise WorkflowError("invalid CloudEvent context string")
        elif type(item) is not bool and (type(item) is not int or not -(1 << 31) <= item < (1 << 31)):
            raise WorkflowError("invalid CloudEvent context value")
    if value.get("specversion") != "1.0" or value.get("datacontenttype") != "application/json" or "data" not in value:
        raise WorkflowError("CloudEvent requires version1.0 and JSON data")
    for name in ("id", "source", "type"):
        if type(value.get(name)) is not str or not value[name]:
            raise WorkflowError(f"CloudEvent requires nonempty {name}")
    if len(value["id"].encode("utf-8")) > 128 or len(value["source"].encode("utf-8")) > 2048:
        raise WorkflowError("CloudEvent id/source exceed their UTF-8 byte limits")
    _validate_event_uri(value["source"])
    for name in ("subject", "dataschema", "time"):
        if name in value and (type(value[name]) is not str or not value[name]):
            raise WorkflowError(f"CloudEvent {name} must be a nonempty string")
    if "dataschema" in value:
        _validate_event_uri(value["dataschema"], absolute=True)
    if "time" in value:
        match = re.fullmatch(r"([0-9]{4})-([0-9]{2})-([0-9]{2})[Tt]([0-9]{2}):([0-9]{2}):([0-9]{2})(?:\.[0-9]+)?(?:[Zz]|([+-])([0-9]{2}):([0-9]{2}))", value["time"])
        if match is None:
            raise WorkflowError("CloudEvent time must be RFC3339")
        year, month, day, hour, minute, second = map(int, match.groups()[:6])
        if (not 1 <= month <= 12 or not 1 <= day <= calendar.monthrange(year, month)[1]
                or hour > 23 or minute > 59 or second > 60
                or (match[7] is not None and (int(match[8]) > 23 or int(match[9]) > 59))):
            raise WorkflowError("invalid CloudEvent RFC3339 timestamp")
        offset = 0 if match[7] is None else (int(match[8]) * 60 + int(match[9]))
        if match[7] == "-":
            offset = -offset
        if second == 60 and not _valid_event_leap_second(year, month, day, hour, minute, offset):
            raise WorkflowError("CloudEvent leap second must be the final UTC second of a month")
    _validate_event_trace(value)
    _encode(value["data"], MAX_EVENT_BYTES, authoritative=authoritative)
    return value


def workflow_context() -> WorkflowContext:
    """Get this activation's context; fail outside a workflow invocation."""
    context = _workflow.get()
    if context is None or context._closed:
        raise WorkflowError("no Ledgence workflow activation is active")
    return context


get_workflow_context = workflow_context


class TaskRef:
    """A staged child key; creation performs no external dispatch."""
    __slots__ = ("key", "_context")

    def __init__(self, key, context):
        self.key = key
        self._context = context


class WorkflowRef(TaskRef):
    """An owned child workflow key, distinct from its controller tasks."""
    __slots__ = ()


class Workflow:
    """Register explicit, enum-addressed continuations in a prepared package."""

    def __init__(self, entries):
        if not isinstance(entries, type) or not issubclass(entries, StrEnum):
            raise WorkflowError("workflow entries must be a StrEnum family")
        if not entries.__members__ or len(entries.__members__) != len(list(entries)):
            raise WorkflowError("workflow entries must be nonempty and cannot contain aliases")
        for entry in entries:
            _text(entry.value, "entrypoint")
        self._entries = entries
        self._handlers = {}
        self._defaults = []
        self._built = None

    def entrypoint(self, entry, *, default=False):
        if self._built is not None:
            raise WorkflowError("workflow registry is frozen")
        if type(entry) is not self._entries:
            raise WorkflowError("entrypoint must belong to this workflow's enum family")
        if type(default) is not bool:
            raise WorkflowError("entrypoint default must be a boolean")

        def register(handler):
            if self._built is not None:
                raise WorkflowError("workflow registry is frozen")
            if not callable(handler):
                raise WorkflowError("entrypoint handler must be callable")
            if entry.value in self._handlers:
                raise WorkflowError("duplicate entrypoint handler")
            self._handlers[entry.value] = handler
            if default:
                self._defaults.append(entry)
            return handler
        return register

    def build(self):
        """Freeze registration and return the package's normal event handler."""
        if self._built is not None:
            return self._built
        if set(self._handlers) != {entry.value for entry in self._entries}:
            raise WorkflowError("every workflow entrypoint requires a handler")
        if len(self._defaults) != 1:
            raise WorkflowError("workflow requires exactly one default entrypoint")
        default = self._defaults[0]
        if "start" in self._handlers and default.value != "start":
            raise WorkflowError("the start entrypoint must be the default")
        handlers = MappingProxyType(dict(self._handlers))
        entries = self._entries

        async def handle(event):
            ctx = workflow_context()
            ctx._active()
            if ctx._entry_registry is not None:
                raise WorkflowError("workflow activation already has an entrypoint registry")
            selected = default.value if ctx.continuation == "start" else ctx.continuation
            if selected not in handlers:
                raise WorkflowError("unknown workflow entrypoint: " + selected)
            ctx._entry_registry = handlers
            ctx._entry_enum = entries
            ctx._entrypoint = entries(selected)
            result = handlers[selected](event, ctx)
            if inspect.isawaitable(result):
                result = await result
            return result

        self._built = handle
        return handle


@dataclass(frozen=True, slots=True)
class BranchSpec:
    """A frozen same-package child specification; construction performs no work."""
    _encoded: bytes
    _context: Any

    @property
    def key(self):
        return json.loads(self._encoded)["key"]


@dataclass(frozen=True, slots=True)
class ForkRef:
    """Acknowledged branch keys, owned by the activation that registered them."""
    key: str
    branch_keys: tuple[str, ...]
    _context: Any


class _LocalResult:
    def __init__(self, task, observed_failures):
        self._task = task
        self._observed_failures = observed_failures

    async def _result(self):
        # A cancelled observer cannot abandon a running local operation. The
        # activation retains ownership and drains it before process reuse.
        try:
            return _freeze(await asyncio.shield(self._task), MAX_RECORD_BYTES, authoritative=True)
        except BaseException as exc:
            if (self._task.done() and not self._task.cancelled()
                    and self._task.exception() is exc):
                self._observed_failures.add(self._task)
            raise

    def __await__(self):
        return self._result().__await__()


class WorkflowContext:
    """One explicit activation. Constructed by the worker, not application code."""

    def __init__(self, payload, rpc):
        payload = _freeze(payload, MAX_CONTEXT_BYTES, 96, authoritative=True)
        _fields(payload, {"v", "workflow_id", "activation_id", "revision", "continuation",
                          "state", "inputs", "local_steps"},
                {"wake", "parent_workflow_id", "root_workflow_id"})
        if type(payload["v"]) is not int or payload["v"] != 1:
            raise WorkflowError("unsupported workflow activation version")
        self.workflow_id = _text(payload["workflow_id"], "workflow_id")
        parent = payload.get("parent_workflow_id")
        root = payload.get("root_workflow_id")
        if (parent is None) != (root is None):
            raise WorkflowError("workflow lineage must contain both parent and root")
        if parent is not None:
            _text(parent, "parent_workflow_id")
            _text(root, "root_workflow_id")
            if self.workflow_id in (parent, root):
                raise WorkflowError("workflow lineage cannot refer to itself")
        self.parent_workflow_id = parent
        self.root_workflow_id = self.workflow_id if root is None else root
        self.activation_id = _text(payload["activation_id"], "activation_id")
        self.revision = _integer(payload["revision"], "revision")
        self.continuation = _text(payload["continuation"], "continuation")
        self._state = _freeze(payload["state"], MAX_STATE_BYTES, authoritative=True)
        self._inputs = payload["inputs"]
        if type(self._inputs) is not dict or len(self._inputs) > MAX_COMMANDS:
            raise WorkflowError("workflow inputs must be a bounded object")
        self._wake = payload.get("wake")
        if self._wake is not None:
            self._validate_wake(self._wake)
        self._approval = None
        self._approval_callable = None
        self._approval_lookup = None
        if self._wake is not None and self._wake["kind"] == "approval":
            approval = self._wake["approval"]
            if (approval["workflow_id"] != self.workflow_id
                    or approval["resumed_activation_id"] != self.activation_id
                    or approval["revision"] + 1 != self.revision):
                raise WorkflowError("approval wake belongs to another workflow activation")
            self._approval = _encode(approval, MAX_DECISION_BYTES, 96, authoritative=True)
        # Preserve old payloads; wake and child inputs share one bounded batch.
        combined = self._inputs if self._wake is None else {"inputs": self._inputs, "wake": self._wake}
        _encode(combined, MAX_DECISION_BYTES, 96, authoritative=True)
        for key, item in self._inputs.items():
            _text(key, "input key")
            self._validate_child(item)
        records = payload["local_steps"]
        if type(records) is not list or len(records) > MAX_STEPS:
            raise WorkflowError("too many local step records")
        _encode(records, MAX_RECORDS_BYTES, 96, authoritative=True)
        self._records = {}
        for record in records:
            self._validate_record(record, authoritative=True)
            if record["key"] in self._records:
                raise WorkflowError("duplicate local step record")
            self._records[record["key"]] = record
        self._rpc = rpc
        self._loop = asyncio.get_running_loop()
        self._commit_lock = asyncio.Lock()
        self._pending = {}
        self._forks = {}
        self._fork_branch_keys = {}
        self._entry_registry = None
        self._entry_enum = None
        self._entrypoint = self.continuation
        self._observed_failures = set()
        self._commands = []
        self._closed = False
        self._fatal = None

    @property
    def entrypoint(self):
        """The selected enum member, or a legacy context's continuation string."""
        return self._entrypoint

    def _target(self, value):
        if self._entry_enum is not None:
            if type(value) is not self._entry_enum:
                raise WorkflowError("entrypoint must belong to this workflow's enum family")
            return value.value
        return _text(value, "continuation")

    @property
    def state(self):
        return _freeze(self._state, MAX_STATE_BYTES, authoritative=True)

    @property
    def inputs(self):
        return _freeze(self._inputs, MAX_DECISION_BYTES, 96, authoritative=True)

    @property
    def wake(self):
        """Return the event, timeout, or timer that resumed this activation."""
        return _freeze(self._wake, MAX_DECISION_BYTES, 96, authoritative=True)

    @property
    def approval(self):
        """Typed immutable approval wake, or None for a different wake kind."""
        return None if self._approval is None else Approval(self._approval)

    @staticmethod
    def _validate_child(item):
        if type(item) is not dict:
            raise WorkflowError("invalid child result")
        workflow = item.get("kind") == "workflow"
        if workflow:
            _fields(item, {"kind", "workflow_id", "state", "outcome"})
            _text(item["workflow_id"], "child workflow_id")
        else:
            _fields(item, {"task_id", "state", "outcome"})
            _text(item["task_id"], "child task_id")
        state, outcome = item["state"], item["outcome"]
        if (state not in ("succeeded", "failed", "cancelled")
                or type(outcome) is not dict or outcome.get("kind") != state):
            raise WorkflowError("child result must have a consistent terminal outcome")
        if state == "cancelled":
            _fields(outcome, {"kind"})
            return
        if workflow:
            _fields(outcome, {"kind", "output" if state == "succeeded" else "error"})
            if state == "succeeded":
                _encode(outcome["output"], MAX_DECISION_BYTES, authoritative=True)
            else:
                WorkflowContext._validate_error(outcome["error"], application=True)
            return
        _fields(outcome, {"kind", "attempt_id", "quiescence", "execution_may_have_started",
                          "output" if state == "succeeded" else "failure"})
        _text(outcome["attempt_id"], "child attempt_id")
        if (outcome["quiescence"] not in ("confirmed", "unconfirmed")
                or type(outcome["execution_may_have_started"]) is not bool):
            raise WorkflowError("invalid child execution evidence")
        if state == "succeeded":
            if not outcome["execution_may_have_started"]:
                raise WorkflowError("successful child requires execution-start evidence")
            _encode(outcome["output"], MAX_DECISION_BYTES, authoritative=True)
            return
        failure = outcome["failure"]
        if type(failure) is not dict:
            raise WorkflowError("invalid child failure")
        kind = failure.get("kind")
        if kind == "application":
            if not outcome["execution_may_have_started"]:
                raise WorkflowError("application failure requires execution-start evidence")
            _fields(failure, {"kind", "error"})
            WorkflowContext._validate_error(failure["error"])
        elif kind == "execution":
            _fields(failure, {"kind", "error", "phase", "cleanup_error"})
            WorkflowContext._validate_error(failure["error"], worker=True)
            if failure["cleanup_error"] is not None:
                WorkflowContext._validate_error(failure["cleanup_error"], worker=True)
            if failure["phase"] not in ("admission", "preparation", "startup", "execution", "cleanup"):
                raise WorkflowError("invalid child failure phase")
        elif kind == "attempt_lost":
            if outcome["quiescence"] != "unconfirmed":
                raise WorkflowError("lost attempt requires unconfirmed quiescence")
            _fields(failure, {"kind"})
        else:
            raise WorkflowError("invalid child failure kind")

    @staticmethod
    def _validate_error(error, *, application=False, worker=False):
        _fields(error, {"kind", "message"})
        if type(error["kind"]) is not str or type(error["message"]) is not str:
            raise WorkflowError("invalid child error")
        if application:
            _text(error["kind"], "workflow error kind")
            if len(error["message"].encode("utf-8")) > 4096:
                raise WorkflowError("workflow error message exceeds its byte limit")
        if worker and error["kind"] not in (
            "invalid_input", "not_found", "integrity", "incompatible", "unavailable",
            "cancelled", "timed_out", "runtime", "protocol", "io", "capacity",
        ):
            raise WorkflowError("invalid worker error kind")

    @staticmethod
    def _validate_wake(wake):
        if type(wake) is not dict:
            raise WorkflowError("invalid workflow wake")
        kind = wake.get("kind")
        if kind == "approval":
            _fields(wake, {"kind", "approval"})
            _validate_approval(wake["approval"])
            if wake["approval"]["status"] == ApprovalStatus.PENDING:
                raise WorkflowError("a pending approval cannot wake a workflow")
            return
        if kind == "event":
            _fields(wake, {"kind", "key", "event", "accepted_at"})
            _validate_event(wake["event"], authoritative=True)
            _integer(wake["accepted_at"], "accepted_at", maximum=MAX_TIMESTAMP)
        elif kind in ("timeout", "timer"):
            _fields(wake, {"kind", "key", "deadline"})
            _integer(wake["deadline"], "deadline", maximum=MAX_TIMESTAMP)
        else:
            raise WorkflowError("invalid workflow wake kind")
        _text(wake["key"], "wake key")

    @staticmethod
    def _validate_wait(wait):
        if type(wait) is not dict:
            raise WorkflowError("invalid workflow wait")
        kind = wait.get("kind")
        if kind == "approval":
            _fields(wait, {"kind", "key", "action", "timeout_ms"}, {"proposed_arguments", "protection"})
            _validate_approval_protection(wait)
            _validate_action(wait["action"])
            _validate_proposed_arguments(wait.get("proposed_arguments"))
            _integer(wait["timeout_ms"], "timeout_ms", maximum=MAX_WAIT_MS)
        elif kind == "event":
            _fields(wait, {"kind", "key", "timeout_ms"})
            if wait["timeout_ms"] is not None:
                _integer(wait["timeout_ms"], "timeout_ms", maximum=MAX_WAIT_MS)
        elif kind == "timer":
            _fields(wait, {"kind", "key", "delay_ms"})
            _integer(wait["delay_ms"], "delay_ms", maximum=MAX_WAIT_MS)
        else:
            raise WorkflowError("invalid workflow wait kind")
        _text(wait["key"], "wait key")

    def _active(self):
        if _local_owner.get() is not None:
            raise WorkflowError("durable local callables cannot stage workflow operations; use the controller")
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError as exc:
            raise WorkflowError("workflow operations require the controller event loop") from exc
        if loop is not self._loop:
            raise WorkflowError("workflow operations require the controller event loop")
        if self._closed:
            raise WorkflowError("workflow activation is closed")
        if self._fatal is not None:
            raise WorkflowError("workflow runtime acknowledgement failed") from self._fatal

    @staticmethod
    def _validate_record(record, *, authoritative=False):
        _fields(record, {"key", "callable", "input", "output"})
        _text(record["key"], "local key")
        _text(record["callable"], "local callable", 512)
        _encode(record["input"], MAX_RECORD_BYTES, authoritative=authoritative)
        _encode(record["output"], MAX_RECORD_BYTES, authoritative=authoritative)
        _encode(record, MAX_RECORD_BYTES, 96, authoritative=authoritative)

    def local(self, key, fn, **kwargs):
        """Start a local step; await its durably acknowledged JSON result.

        Use explicit JSON keyword arguments for every value affecting the
        operation. A callable's closure is not part of its persisted binding.
        Concurrent calls sharing a key and binding share one owned execution.
        """
        if type(key) is str and key.startswith(_APPROVAL_LOCAL_PREFIX):
            raise WorkflowError("approval local keys are reserved for approved actions")
        return self._local(key, fn, kwargs)

    def operation(self, key, fn, *, kind: OperationKind, version: str, arguments: dict):
        """Start a model/tool call with frozen effective JSON keyword arguments.

        Kind, callable identity, version, and signature-bound arguments (including
        defaults) form the durable binding. Awaiting returns only the completed,
        durably acknowledged JSON result. Include every effective model/tool
        setting in arguments. Keep clients and credentials outside arguments;
        closure state is not captured.
        External effects still need application idempotency or reconciliation.
        """
        self._active()
        _text(key, "operation key")
        if key.startswith(_APPROVAL_LOCAL_PREFIX):
            raise WorkflowError("approval local keys are reserved for approved actions")
        if type(kind) is not OperationKind:
            raise WorkflowError("operation kind must be an OperationKind member")
        _text(version, "operation version")
        if type(arguments) is not dict:
            raise WorkflowError("operation arguments must be a JSON object")
        name = _callable_name(fn, label="operation")
        # Validate supplied values before binding and freeze defaults before
        # returning the owned awaitable. Only exact accepted replay may use the
        # bounded Python/Rust float encoding allowance.
        authoritative = key in self._records
        _encode(arguments, MAX_RECORD_BYTES, authoritative=authoritative)
        effective = _freeze(_effective_arguments(fn, arguments, label="operation"),
                            MAX_RECORD_BYTES, authoritative=authoritative)
        request = {"v": 1, "kind": kind.value, "version": version, "arguments": effective}
        _encode(request, MAX_RECORD_BYTES, authoritative=authoritative)
        # A semantic prefix keeps this binding distinct from an ordinary local
        # call with coincidentally matching envelope-shaped keyword arguments.
        return self._bound_local(key, fn, _text(kind.value + ":" + name, "operation callable", 512),
                                 request, effective)

    def approved_local(self, fn, *, version):
        """Run only the authoritative approved action's saved arguments.

        The callable identity and version must match. Retries use the existing
        durable local-step record. External effects still require idempotency:
        a crash can occur after an effect and before its result is committed.
        Operator-trusted callable code remains responsible for its own effects.
        """
        key, approval = self._approved_action(fn, version)
        if approval.get("protection") == ApprovalProtection.EXTERNAL_EFFECT:
            raise WorkflowError("this approval requires approved_effect with a separate lookup callback")
        return self._local(key, fn, approval["action"]["arguments"])

    def approved_effect(self, fn, *, lookup, version):
        """Dispatch once on the original grant, or look up the approved action.

        Use distinct, named callbacks accepting the approved keyword arguments. Only the lookup
        callback runs on a replacement grant and it must be read-only. Return
        provider-confirmed JSON, or raise EffectOutcomeUnknown if the outcome
        cannot be verified. Accepted results replay without contacting the
        orchestrator or the provider.
        """
        key, approval = self._approved_action(fn, version)
        action = approval["action"]
        lookup_name = _callable_name(lookup, label="effect lookup")
        if lookup_name == action["name"] or _same_callable(fn, lookup):
            raise WorkflowError("effect lookup must be separate from dispatch")
        self._check_approved_arguments(lookup, action["arguments"])
        if self._approval_lookup is not None and not _same_callable(self._approval_lookup, lookup):
            raise WorkflowError("approval is already bound to a different lookup")
        self._approval_lookup = lookup

        async def invoke(**saved):
            mode = await self._claim_approved_effect(approval["key"], action, lookup_name)
            result = (fn if mode == "dispatch" else lookup)(**saved)
            return await result if inspect.isawaitable(result) else result

        # Use the same reserved occurrence key as approved_local. A changed
        # helper, action version or lookup cannot silently reuse its result.
        # Store the full canonical action as JSON text. Wrapping its arguments
        # in another JSON object would exceed the journal's 64-level input
        # limit for a valid 64-level approval, after the mutation had run.
        action_json = _encode(action, MAX_APPROVAL_BYTES, 96, authoritative=True).decode("utf-8")
        previous = self._records.get(key)
        if previous is not None and type(previous["input"]) is dict:
            saved_json = previous["input"].get("action_json")
            if isinstance(saved_json, str) and saved_json != action_json:
                # Other workers may serialize the approved action in a different
                # field order. Replay its original bytes only after strict comparison.
                if _replayed_action_json(saved_json) != action_json:
                    raise WorkflowError("approved effect action differs from its stored binding")
                action_json = saved_json
        binding = {"v": 1, "action_json": action_json, "lookup": lookup_name}
        return self._bound_local(key, invoke, action["name"], binding, action["arguments"],
                                 approval_key=approval["key"])

    async def _claim_approved_effect(self, approval_key, action, lookup):
        request = {"approval_key": approval_key, "action": action, "lookup": lookup}
        async with self._commit_lock:
            if self._fatal is not None:
                raise WorkflowError("workflow runtime acknowledgement failed") from self._fatal
            try:
                reply = await self._rpc("approved_effect.claim", request)
                _fields(reply, {"workflow_id", "activation_id", "approval_key", "action", "lookup", "disposition"})
                if (reply["workflow_id"] != self.workflow_id or reply["activation_id"] != self.activation_id
                        or reply["approval_key"] != approval_key or reply["lookup"] != lookup
                        or reply["disposition"] not in ("dispatch", "lookup_only")
                        or _encode(reply["action"], MAX_APPROVAL_BYTES, 96, authoritative=True)
                        != _encode(action, MAX_APPROVAL_BYTES, 96, authoritative=True)):
                    raise WorkflowError("invalid approved effect claim acknowledgement")
            except BaseException as exc:
                self._fatal = exc
                raise
        return reply["disposition"]

    def _approved_action(self, fn, version):
        self._active()
        if self._approval is None:
            raise WorkflowError("this activation has no approval")
        approval = json.loads(self._approval)
        action = approval["action"]
        if approval["status"] != ApprovalStatus.APPROVED:
            raise WorkflowError("the action was not approved")
        if _callable_name(fn) != action["name"] or _text(version, "action version") != action["version"]:
            raise WorkflowError("callable identity or version differs from the approved action")
        # Direct action construction can omit defaults, and code can add a
        # new optional argument across deployments. Neither may introduce an
        # argument that was absent from the reviewed effective action.
        self._check_approved_arguments(fn, action["arguments"])
        if self._approval_callable is not None and not _same_callable(self._approval_callable, fn):
            raise WorkflowError("approval is already bound to a different callable")
        self._approval_callable = fn
        key = _APPROVAL_LOCAL_PREFIX + hashlib.sha256(approval["key"].encode("utf-8")).hexdigest()
        return key, approval

    @staticmethod
    def _check_approved_arguments(fn, arguments):
        effective = _effective_arguments(fn, arguments)
        if (_encode(effective, MAX_APPROVAL_BYTES, authoritative=True)
                != _encode(arguments, MAX_APPROVAL_BYTES, authoritative=True)):
            raise WorkflowError("callable defaults differ from the approved effective arguments")

    def _local(self, key, fn, arguments):
        self._active()
        _text(key, "local key")
        if not callable(fn):
            raise WorkflowError("local step requires a callable")
        module = getattr(fn, "__module__", None)
        name = getattr(fn, "__qualname__", None)
        if not module or not name:
            raise WorkflowError("local callable requires a stable module and qualified name")
        arguments = _freeze(arguments, MAX_RECORD_BYTES, authoritative=key in self._records)
        return self._bound_local(key, fn, _text(module + ":" + name, "local callable", 512),
                                 arguments, arguments)

    def _bound_local(self, key, fn, name, persisted_input, arguments, *, approval_key=None):
        previous = self._records.get(key)
        # Exact replay may copy an accepted Rust-size-boundary binding whose
        # Python float text is longer. A new binding never receives this slack.
        binding = {"key": key, "callable": name, "input": persisted_input}
        binding_bytes = _encode(binding, MAX_RECORD_BYTES, 96, authoritative=previous is not None)
        if previous is not None:
            actual = {field: previous[field] for field in ("key", "callable", "input")}
            if _encode(actual, MAX_RECORD_BYTES, 96, authoritative=True) != binding_bytes:
                raise WorkflowError("local step key was reused with a different binding")
        if key in self._pending:
            known, task = self._pending[key]
            if known != binding_bytes:
                raise WorkflowError("local step key was reused with a different binding")
            return _LocalResult(task, self._observed_failures)
        if len(set(self._records) | set(self._pending)) >= MAX_STEPS and previous is None:
            raise WorkflowError("too many local steps in one activation")
        task = asyncio.create_task(self._run_local(binding, fn, arguments, previous, approval_key))
        self._pending[key] = (binding_bytes, task)
        return _LocalResult(task, self._observed_failures)

    async def _run_local(self, binding, fn, arguments, previous, approval_key):
        from ledgence.worker._observations import begin_local, finish_local
        observation = begin_local(binding, replayed=previous is not None)
        if previous is not None:
            finish_local(observation, "replayed")
            return previous["output"]
        # Sync functions retain normal synchronous semantics. Async functions
        # can overlap I/O without allocating additional subprocesses or threads.
        token = _local_owner.set(self)
        try:
            output = fn(**_freeze(arguments, MAX_RECORD_BYTES))
            if inspect.isawaitable(output):
                output = await output
            record = dict(binding, output=_freeze(output, MAX_RECORD_BYTES))
            self._validate_record(record)
        except BaseException as exc:
            finish_local(observation, "cancelled" if isinstance(exc, asyncio.CancelledError) else "failed")
            raise
        else:
            # A callable returning is distinct from its result being accepted.
            finish_local(observation, "returned")
        finally:
            _local_owner.reset(token)
        async with self._commit_lock:
            _encode([*self._records.values(), record], MAX_RECORDS_BYTES, 96)
            try:
                if approval_key is None:
                    result = await self._rpc("local_step.commit", record)
                else:
                    result = await self._rpc("approved_effect.confirm", {
                        "approval_key": approval_key, "lookup": binding["input"]["lookup"], "record": record,
                    })
                if type(result) is not dict or result != {"committed": True} or type(result["committed"]) is not bool:
                    raise WorkflowError("invalid local step commit acknowledgement")
            except BaseException as exc:
                self._fatal = exc
                raise
            self._records[binding["key"]] = record
        return record["output"]

    async def gather(self, *operations):
        """Wait for all supplied local operations, retaining ownership on error."""
        self._active()
        if len(operations) > MAX_STEPS:
            raise WorkflowError("too many gathered operations")
        results = await asyncio.gather(*operations, return_exceptions=True)
        for result in results:
            if isinstance(result, BaseException):
                raise result
        return results

    def task(self, key, *, program, version, queue, data, retry_policy=None,
             attempt_timeout_ms=300000):
        """Stage a workflow-scoped child key for the next atomic checkpoint.

        Reusing a key reuses the original child only if its binding is identical.
        Include an iteration suffix when a loop should create another child.
        """
        return self._child("task", key, program=program, version=version, queue=queue,
                           data=data, retry_policy=retry_policy,
                           attempt_timeout_ms=attempt_timeout_ms)

    def workflow(self, key, *, program, version, queue, data, retry_policy=None,
                 attempt_timeout_ms=300000):
        """Stage an owned subworkflow; await its terminal outcome with suspend.

        Task and workflow keys share a parent-wide namespace. A child retains
        its own workflow identity and activation retries. Parent cancellation
        or failure drains the owned tree; child failure is an inspectable result.
        """
        return self._child("workflow", key, program=program, version=version, queue=queue,
                           data=data, retry_policy=retry_policy,
                           attempt_timeout_ms=attempt_timeout_ms)

    def _child(self, kind, key, *, program, version, queue, data, retry_policy,
               attempt_timeout_ms):
        self._active()
        _text(key, "child key")
        for name, value in (("program", program), ("version", version)):
            if type(value) is not str or value in (".", "..") or not re.fullmatch(r"[a-z0-9._-]{1,128}", value):
                raise WorkflowError(f"invalid {name}")
        _text(queue, "queue")
        policy = {"max_attempts": 3, "retry_delay_ms": 5000} if retry_policy is None else retry_policy
        policy = _freeze(policy, 1024)
        _fields(policy, {"max_attempts", "retry_delay_ms"})
        _integer(policy["max_attempts"], "max_attempts", 1, 1000)
        _integer(policy["retry_delay_ms"], "retry_delay_ms", 0, 86400000)
        _integer(attempt_timeout_ms, "attempt_timeout_ms", 60000, 86400000)
        if key in self._fork_branch_keys:
            raise WorkflowError("child key already belongs to a fork")
        command = {"key": key, "program": {"id": program, "version": version}, "queue": queue,
                   "data": _freeze(data, MAX_DECISION_BYTES), "retry_policy": policy,
                   "attempt_timeout_ms": attempt_timeout_ms}
        reference = WorkflowRef if kind == "workflow" else TaskRef
        if kind == "workflow":
            command["kind"] = "workflow"
        for previous in self._commands:
            if previous["key"] == key:
                if _encode(previous, MAX_DECISION_BYTES, 96) != _encode(command, MAX_DECISION_BYTES, 96):
                    raise WorkflowError("child key reused with a different binding")
                return reference(key, self)
        if len(self._commands) >= MAX_COMMANDS:
            raise WorkflowError("too many staged children")
        _encode([*self._commands, command], MAX_DECISION_BYTES, 96)
        self._commands.append(command)
        return reference(key, self)

    def branch(self, key, *, entrypoint, queue, data, retry_policy=None,
               attempt_timeout_ms=300000):
        """Describe an owned branch in this exact package without starting it."""
        self._active()
        key = _text(key, "branch key")
        entrypoint = self._target(entrypoint)
        _text(queue, "queue")
        policy = {"max_attempts": 3, "retry_delay_ms": 5000} if retry_policy is None else retry_policy
        policy = _freeze(policy, 1024)
        _fields(policy, {"max_attempts", "retry_delay_ms"})
        _integer(policy["max_attempts"], "max_attempts", 1, 1000)
        _integer(policy["retry_delay_ms"], "retry_delay_ms", 0, 86400000)
        _integer(attempt_timeout_ms, "attempt_timeout_ms", 60000, 86400000)
        value = {"key": key, "entrypoint": entrypoint, "queue": queue,
                 "data": _freeze(data, MAX_FORK_BYTES), "retry_policy": policy,
                 "attempt_timeout_ms": attempt_timeout_ms}
        return BranchSpec(_encode(value, MAX_FORK_BYTES, 96), self)

    def _validate_branch(self, value):
        _fields(value, {"key", "entrypoint", "queue", "data", "retry_policy", "attempt_timeout_ms"})
        for field in ("key", "entrypoint", "queue"):
            _text(value[field], "branch " + field)
        if self._entry_registry is not None and value["entrypoint"] not in self._entry_registry:
            raise WorkflowError("unknown workflow entrypoint")
        policy = value["retry_policy"]
        _fields(policy, {"max_attempts", "retry_delay_ms"})
        _integer(policy["max_attempts"], "max_attempts", 1, 1000)
        _integer(policy["retry_delay_ms"], "retry_delay_ms", 0, 86400000)
        _integer(value["attempt_timeout_ms"], "attempt_timeout_ms", 60000, 86400000)
        _encode(value["data"], MAX_FORK_BYTES)

    async def fork(self, key, *, branches):
        """Await durable child registration, then continue this activation.

        Acknowledgment records scheduling obligations, not child completion.
        Reusing a workflow-wide key requires exactly the same ordered branches.
        """
        self._active()
        key = _text(key, "fork key")
        if type(branches) not in (list, tuple) or not 1 <= len(branches) <= MAX_COMMANDS:
            raise WorkflowError("fork requires between 1 and 64 branches")
        values = []
        for branch in branches:
            if type(branch) is not BranchSpec or branch._context is not self:
                raise WorkflowError("branch specification belongs to another activation")
            try:
                value = json.loads(branch._encoded)
            except (TypeError, ValueError, UnicodeError) as exc:
                raise WorkflowError("invalid branch specification") from exc
            self._validate_branch(value)
            values.append(value)
        keys = tuple(value["key"] for value in values)
        if len(set(keys)) != len(keys):
            raise WorkflowError("fork branch keys must be distinct")
        request = {"key": key, "branches": values}
        binding = _encode(request, MAX_FORK_BYTES, 96)
        if key in self._forks:
            previous, task = self._forks[key]
            if previous != binding:
                raise WorkflowError("fork key reused with a different binding")
        else:
            if any(value["key"] in keys for value in self._commands):
                raise WorkflowError("branch key already belongs to a staged child")
            if any(branch_key in self._fork_branch_keys for branch_key in keys):
                raise WorkflowError("branch key already belongs to a fork")
            task = asyncio.create_task(self._register_fork(key, keys, request))
            self._forks[key] = (binding, task)
            self._fork_branch_keys.update((branch_key, key) for branch_key in keys)
        try:
            return await asyncio.shield(task)
        except BaseException as exc:
            if task.done() and not task.cancelled() and task.exception() is exc:
                self._observed_failures.add(task)
            raise

    async def _register_fork(self, key, keys, request):
        async with self._commit_lock:
            if self._fatal is not None:
                raise WorkflowError("workflow runtime acknowledgement failed") from self._fatal
            try:
                reply = await self._rpc("workflow.fork", request)
                if (type(reply) is not dict
                        or set(reply) != {"committed", "key", "branch_keys"}
                        or reply["committed"] is not True
                        or type(reply["key"]) is not str or reply["key"] != key
                        or type(reply["branch_keys"]) is not list
                        or any(type(value) is not str for value in reply["branch_keys"])
                        or reply["branch_keys"] != list(keys)):
                    raise WorkflowError("invalid workflow fork acknowledgement")
            except BaseException as exc:
                self._fatal = exc
                raise
        return ForkRef(key, keys, self)

    def join(self, fork, *, resume, state):
        """Checkpoint and release this invocation until all branches are terminal."""
        self._active()
        if type(fork) is not ForkRef or fork._context is not self:
            raise WorkflowError("fork reference belongs to another activation")
        registered = self._forks.get(fork.key)
        if (registered is None or not registered[1].done() or registered[1].cancelled()
                or registered[1].exception() is not None or registered[1].result() is not fork):
            raise WorkflowError("fork reference was not acknowledged by this activation")
        return self.suspend(continuation=resume, state=state, until=fork.branch_keys)

    def _key(self, ref):
        if isinstance(ref, TaskRef):
            if ref._context is not self:
                raise WorkflowError("child reference belongs to another activation")
            return ref.key
        return _text(ref, "child key")

    def get_result(self, ref):
        """Return a successful child's output; fail if absent or not successful."""
        self._active()
        key = self._key(ref)
        item = self._inputs.get(key)
        if item is None:
            raise WorkflowError("child result is absent from this activation")
        if isinstance(ref, TaskRef) and ((isinstance(ref, WorkflowRef)) != (item.get("kind") == "workflow")):
            raise WorkflowError("child reference kind does not match the result")
        outcome = item["outcome"]
        if (item["state"] != "succeeded" or type(outcome) is not dict
                or outcome.get("kind") != "succeeded" or "output" not in outcome):
            raise WorkflowError("child did not succeed; inspect inputs for its outcome")
        return _freeze(outcome["output"], MAX_DECISION_BYTES, authoritative=True)

    def _decision(self, kind, **fields):
        self._active()
        return _freeze({"v": 1, "activation_id": self.activation_id, "revision": self.revision,
                        "kind": kind, **fields}, MAX_DECISION_BYTES, 96)

    def suspend(self, *, continuation, state, until=()):
        """Checkpoint and wait until every specified child is terminal."""
        self._active()
        if type(until) not in (list, tuple) or len(until) > MAX_COMMANDS:
            raise WorkflowError("until must be a bounded list or tuple of child references")
        keys = [self._key(ref) for ref in until]
        if len(set(keys)) != len(keys):
            raise WorkflowError("wait references must be distinct child keys")
        # A key can refer to a child created by an earlier activation, absent
        # from this frozen input batch. The orchestrator verifies its existence.
        return self._decision("suspend", continuation=self._target(continuation),
                              state=_freeze(state, MAX_STATE_BYTES), commands=self._commands,
                              until=keys)

    def wait_event(self, key, *, continuation, state, timeout_ms=None):
        """Checkpoint and wait for one external event, optionally until a deadline.

        The key is one-shot across the workflow run. Return this decision from
        the controller; preparing it does not dispatch or wait in Python.
        """
        self._active()
        wait = {"kind": "event", "key": key, "timeout_ms": timeout_ms}
        self._validate_wait(wait)
        return self._decision("wait", continuation=self._target(continuation),
                              state=_freeze(state, MAX_STATE_BYTES),
                              commands=self._commands, wait=wait)

    def request_approval(self, key, *, action, state, timeout_ms,
                         continuation=None, resume=None, proposed_arguments=None):
        """Checkpoint an immutable effective action and release the worker slot.

        Normalize arguments before requesting approval. The original proposal
        is optional audit context; only action.arguments may execute. Return
        this decision from the workflow controller. Every request has a finite
        server-owned deadline, including an immediate expiry when timeout is 0.
        """
        return self._request_approval(key, action=action, state=state, timeout_ms=timeout_ms,
                                      continuation=continuation, resume=resume,
                                      proposed_arguments=proposed_arguments, protection=None)

    def request_effect_approval(self, key, *, action, state, timeout_ms,
                                continuation=None, resume=None, proposed_arguments=None):
        """Request an action that must execute through approved_effect.

        The saved execution contract rejects approved_local and generic journal
        writes for this occurrence. The separate lookup callback reconciles an
        uncertain provider result after the first dispatch grant.
        """
        return self._request_approval(key, action=action, state=state, timeout_ms=timeout_ms,
                                      continuation=continuation, resume=resume,
                                      proposed_arguments=proposed_arguments,
                                      protection=ApprovalProtection.EXTERNAL_EFFECT)

    def _request_approval(self, key, *, action, state, timeout_ms, continuation,
                          resume, proposed_arguments, protection):
        self._active()
        if (continuation is None) == (resume is None):
            raise WorkflowError("supply exactly one continuation or resume entrypoint")
        target = continuation if resume is None else resume
        value = action.to_dict() if type(action) is ApprovalAction else action
        wait = {"kind": "approval", "key": key, "action": value,
                "timeout_ms": timeout_ms}
        if proposed_arguments is not None:
            wait["proposed_arguments"] = proposed_arguments
        if protection is not None:
            wait["protection"] = protection.value
        self._validate_wait(wait)
        return self._decision("wait", continuation=self._target(target),
                              state=_freeze(state, MAX_STATE_BYTES),
                              commands=self._commands, wait=wait)

    wait_approval = request_approval

    def sleep(self, key, delay_ms, *, continuation, state):
        """Checkpoint a durable timer and release this invocation's worker slot.

        Return this decision. The orchestrator owns the timer; this method does
        not block, sleep, or keep a Python process alive until the deadline.
        """
        self._active()
        wait = {"kind": "timer", "key": key, "delay_ms": delay_ms}
        self._validate_wait(wait)
        return self._decision("wait", continuation=self._target(continuation),
                              state=_freeze(state, MAX_STATE_BYTES),
                              commands=self._commands, wait=wait)

    def continue_(self, *, continuation, state):
        """Commit a checkpoint and request another activation without a wait."""
        return self._decision("continue", continuation=self._target(continuation),
                              state=_freeze(state, MAX_STATE_BYTES), commands=self._commands)

    def complete(self, output):
        _encode(output, MAX_DECISION_BYTES)
        if self._commands:
            raise WorkflowError("complete cannot discard staged child commands; checkpoint first")
        return self._decision("complete", output=output)

    def fail(self, kind, message):
        if type(message) is not str or len(message.encode("utf-8")) > 4096:
            raise WorkflowError("error message must be at most 4096 UTF-8 bytes")
        return self._decision("fail", error={"kind": _text(kind, "error kind"), "message": message})

    def _validate_decision(self, decision):
        self._active()
        common = {"v", "activation_id", "revision", "kind"}
        if type(decision) is not dict:
            raise WorkflowError("workflow handler must return a workflow decision")
        kind = decision.get("kind")
        if type(kind) is not str:
            raise WorkflowError("invalid workflow decision kind")
        extra = {"complete": {"output"}, "fail": {"error"},
                 "continue": {"continuation", "state", "commands"},
                 "suspend": {"continuation", "state", "commands", "until"},
                 "wait": {"continuation", "state", "commands", "wait"}}.get(kind)
        if extra is None:
            raise WorkflowError("invalid workflow decision kind")
        if kind == "complete" and self._commands:
            raise WorkflowError("complete cannot discard staged child commands")
        _fields(decision, common | extra)
        if (type(decision["v"]) is not int or decision["v"] != 1
                or decision["activation_id"] != self.activation_id
                or type(decision["revision"]) is not int or decision["revision"] != self.revision):
            raise WorkflowError("workflow decision changed activation identity")
        if kind == "complete":
            _encode(decision["output"], MAX_DECISION_BYTES)
        if kind in ("suspend", "continue", "wait"):
            _text(decision["continuation"], "continuation")
            if (self._entry_registry is not None
                    and decision["continuation"] not in self._entry_registry):
                raise WorkflowError("unknown workflow entrypoint")
            if (_encode(decision["commands"], MAX_DECISION_BYTES, 96)
                    != _encode(self._commands, MAX_DECISION_BYTES, 96)):
                raise WorkflowError("workflow decision does not contain the staged child commands")
            _encode(decision["state"], MAX_STATE_BYTES)
            for command in decision["commands"]:
                _encode(command["data"], MAX_DECISION_BYTES)
        if kind == "wait":
            self._validate_wait(decision["wait"])
        return _freeze(decision, MAX_DECISION_BYTES, 96)

    async def _drain(self):
        # Retain controller-owned operations started by asynchronous controller
        # work while an earlier batch is draining. Local callables cannot stage work.
        while True:
            tasks = [task for _, task in (*self._pending.values(), *self._forks.values())]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for task, result in zip(tasks, results):
                if isinstance(result, BaseException) and task not in self._observed_failures:
                    if isinstance(result, Exception):
                        raise result
                    raise WorkflowError("an owned workflow operation was cancelled") from result
            if len(tasks) == len(self._pending) + len(self._forks):
                return

    async def _finish(self, cancel=False):
        self._closed = True
        tasks = [task for _, task in (*self._pending.values(), *self._forks.values())]
        if cancel:
            for task in tasks:
                task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
